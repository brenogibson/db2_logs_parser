import json
import pandas as pd
import pyarrow
import boto3
import urllib.parse


s3 = boto3.client('s3')


def extract_columns(content):
	columns = []
	for row in content:
		col = row.split("=")
		if len(col)<2:
			continue
		if(col[0] not in columns):
			columns.append(col[0])
	return columns

def get_entries_dataframe(columns, content):
	df = pd.DataFrame(columns=columns)
	df_row = {}
	for row in content:
		if(row == ''):
			if(df_row):
				df = df.append(df_row, ignore_index=True)
				df_row = {}
			continue
		key_value = row.split("=")
		if(len(key_value) == 2):
			df_row[key_value[0]] = key_value[1]
	return df

def lambda_handler(event, context):
    bucket = event['Records'][0]['s3']['bucket']['name']
    file_key = urllib.parse.unquote_plus(event['Records'][0]['s3']['object']['key'], encoding='utf-8')
    
    
    try:
        response = s3.get_object(Bucket=bucket, Key=file_key)
        content = [row.strip().strip(";").replace(" ", "_") for row in response['Body'].read().decode('utf-8').splitlines()]
        
        # pega os nomes de todos atributos
        columns = extract_columns(content)
        
        # cria dataframe
        df = get_entries_dataframe(columns, content)
        df.index.name = 'index'
        
        # strip directory from filename
        file_key=file_key.split("/")[-1]
        
        df.to_parquet('/tmp/'+file_key+'.parquet')
        df.to_csv('/tmp/'+file_key+'.csv')
        s3.upload_file('/tmp/'+file_key+'.parquet', bucket, 'parquet/'+file_key+'.parquet')
        s3.upload_file('/tmp/'+file_key+'.csv', bucket, 'csv/'+file_key+'.csv')
        
        
        return response['ContentType']
    except Exception as e:
        print(e)
        print('Error getting object {} from bucket {}. Make sure they exist and your bucket is in the same region as this function.'.format(key, bucket))
        raise e
    
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
